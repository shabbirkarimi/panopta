"""
Panopta top Countermeasure

Copyright 2017, Panopta LLC
admin@panopta.com

"""

from CountermeasurePlugin import CountermeasurePlugin
import sys

class Traceroute2Countermeasure(CountermeasurePlugin):

    name = "traceroute2"
    textkey = "info.traceroute2"
    description = "Gather most recent traceroute output"
    max_frequency = None
    max_runtime = None
    sudo_requirements = []
    author = "support@panopta.com"

    def run(self):
        """
        Execute the countermeasure action
        """

        if 'freebsd' in sys.platform or "darwin" in sys.platform:
            return_code, output = self.execute("/usr/sbin/traceroute %s" % self.metadata.get("resource", {}).get("resource_option", "test.com"))
	else:
            return_code, output = self.execute("/usr/bin/traceroute %s" % self.metadata.get("resource", {}).get("resource_option", "test.com"))

        #output = str(self.metadata)

        self.save_text_output(output)
        self.save_return_code(return_code)
